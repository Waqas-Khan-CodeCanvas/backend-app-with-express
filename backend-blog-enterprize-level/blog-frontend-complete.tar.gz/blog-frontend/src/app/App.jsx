import { BrowserRouter } from 'react-router-dom';
import { useEffect } from 'react';
import Router from './router';
import useAuthStore from '@store/authStore';
import useThemeStore from '@store/themeStore';

function App() {
  const { accessToken } = useAuthStore();
  const { theme } = useThemeStore();
  
  // Initialize auth token in global variable for API interceptor
  useEffect(() => {
    if (accessToken) {
      window.__ACCESS_TOKEN__ = accessToken;
    }
  }, [accessToken]);
  
  // Apply theme class to document
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);
  
  return (
    <BrowserRouter>
      <Router />
    </BrowserRouter>
  );
}

export default App;
