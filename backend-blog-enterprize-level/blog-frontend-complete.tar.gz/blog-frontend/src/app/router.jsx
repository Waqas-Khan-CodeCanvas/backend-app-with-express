import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { ROUTES } from '@constants';
import LoadingSpinner from '@components/shared/LoadingSpinner';
import ProtectedRoute from '@components/shared/ProtectedRoute';
import GuestRoute from '@components/shared/GuestRoute';
import PublicLayout from '@components/layout/PublicLayout';
import DashboardLayout from '@components/layout/DashboardLayout';

// Lazy load pages for code splitting
// Auth Pages
const LoginPage = lazy(() => import('@features/auth/pages/LoginPage'));
const RegisterPage = lazy(() => import('@features/auth/pages/RegisterPage'));
const ForgotPasswordPage = lazy(() => import('@features/auth/pages/ForgotPasswordPage'));
const ResetPasswordPage = lazy(() => import('@features/auth/pages/ResetPasswordPage'));
const VerifyEmailPage = lazy(() => import('@features/auth/pages/VerifyEmailPage'));

// Public Pages
const HomePage = lazy(() => import('@features/posts/pages/HomePage'));
const PostsPage = lazy(() => import('@features/posts/pages/PostsPage'));
const PostDetailPage = lazy(() => import('@features/posts/pages/PostDetailPage'));
const CategoryPage = lazy(() => import('@features/categories/pages/CategoryPage'));

// User Pages
const ProfilePage = lazy(() => import('@features/auth/pages/ProfilePage'));
const CreatePostPage = lazy(() => import('@features/posts/pages/CreatePostPage'));
const EditPostPage = lazy(() => import('@features/posts/pages/EditPostPage'));
const MyPostsPage = lazy(() => import('@features/posts/pages/MyPostsPage'));

// Admin Pages
const AdminDashboardPage = lazy(() => import('@features/admin/pages/AdminDashboardPage'));
const AdminUsersPage = lazy(() => import('@features/admin/pages/AdminUsersPage'));
const AdminPostsPage = lazy(() => import('@features/admin/pages/AdminPostsPage'));
const AdminCommentsPage = lazy(() => import('@features/admin/pages/AdminCommentsPage'));
const AdminCategoriesPage = lazy(() => import('@features/admin/pages/AdminCategoriesPage'));

// 404 Page
const NotFoundPage = lazy(() => import('@components/shared/NotFoundPage'));

// Loading fallback
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center">
    <LoadingSpinner size="large" />
  </div>
);

function Router() {
  return (
    <Suspense fallback={<PageLoader />}>
      <Routes>
        {/* Public Routes */}
        <Route element={<PublicLayout />}>
          <Route path={ROUTES.HOME} element={<HomePage />} />
          <Route path={ROUTES.POSTS} element={<PostsPage />} />
          <Route path={ROUTES.POST_DETAIL} element={<PostDetailPage />} />
          <Route path={ROUTES.CATEGORY} element={<CategoryPage />} />
          <Route path={ROUTES.CATEGORIES} element={<CategoryPage />} />
        </Route>

        {/* Guest Only Routes (redirect to home if authenticated) */}
        <Route element={<GuestRoute />}>
          <Route path={ROUTES.LOGIN} element={<LoginPage />} />
          <Route path={ROUTES.REGISTER} element={<RegisterPage />} />
          <Route path={ROUTES.FORGOT_PASSWORD} element={<ForgotPasswordPage />} />
          <Route path={ROUTES.RESET_PASSWORD} element={<ResetPasswordPage />} />
        </Route>

        {/* Email Verification (Public) */}
        <Route path={ROUTES.VERIFY_EMAIL} element={<VerifyEmailPage />} />

        {/* Protected Routes (require authentication) */}
        <Route element={<ProtectedRoute />}>
          <Route element={<PublicLayout />}>
            <Route path={ROUTES.PROFILE} element={<ProfilePage />} />
            <Route path={ROUTES.MY_POSTS} element={<MyPostsPage />} />
            <Route path={ROUTES.POST_CREATE} element={<CreatePostPage />} />
            <Route path={ROUTES.POST_EDIT} element={<EditPostPage />} />
          </Route>
        </Route>

        {/* Admin Routes (require admin role) */}
        <Route element={<ProtectedRoute requiredRole="admin" />}>
          <Route element={<DashboardLayout />}>
            <Route path={ROUTES.ADMIN} element={<Navigate to={ROUTES.ADMIN_DASHBOARD} replace />} />
            <Route path={ROUTES.ADMIN_DASHBOARD} element={<AdminDashboardPage />} />
            <Route path={ROUTES.ADMIN_USERS} element={<AdminUsersPage />} />
            <Route path={ROUTES.ADMIN_POSTS} element={<AdminPostsPage />} />
            <Route path={ROUTES.ADMIN_COMMENTS} element={<AdminCommentsPage />} />
            <Route path={ROUTES.ADMIN_CATEGORIES} element={<AdminCategoriesPage />} />
          </Route>
        </Route>

        {/* 404 Not Found */}
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </Suspense>
  );
}

export default Router;
