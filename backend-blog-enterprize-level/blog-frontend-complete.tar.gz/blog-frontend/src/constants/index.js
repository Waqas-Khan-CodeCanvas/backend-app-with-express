// API Configuration
export const API_CONFIG = {
  BASE_URL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api/v1',
  TIMEOUT: Number(import.meta.env.VITE_API_TIMEOUT) || 30000
};

// User Roles
export const USER_ROLES = {
  USER: 'user',
  AUTHOR: 'author',
  MODERATOR: 'moderator',
  ADMIN: 'admin'
};

// Post Status
export const POST_STATUS = {
  DRAFT: 'draft',
  PUBLISHED: 'published',
  ARCHIVED: 'archived'
};

// Comment Status
export const COMMENT_STATUS = {
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  SPAM: 'spam'
};

// Routes
export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  REGISTER: '/register',
  FORGOT_PASSWORD: '/forgot-password',
  RESET_PASSWORD: '/reset-password/:token',
  VERIFY_EMAIL: '/verify-email/:token',
  
  // Posts
  POSTS: '/posts',
  POST_DETAIL: '/posts/:slug',
  POST_CREATE: '/posts/create',
  POST_EDIT: '/posts/:id/edit',
  POST_PREVIEW: '/posts/:id/preview',
  
  // Categories
  CATEGORY: '/category/:slug',
  CATEGORIES: '/categories',
  
  // Tags
  TAG: '/tag/:name',
  
  // User
  PROFILE: '/profile',
  SETTINGS: '/settings',
  MY_POSTS: '/my-posts',
  
  // Admin
  ADMIN: '/admin',
  ADMIN_DASHBOARD: '/admin/dashboard',
  ADMIN_USERS: '/admin/users',
  ADMIN_POSTS: '/admin/posts',
  ADMIN_COMMENTS: '/admin/comments',
  ADMIN_CATEGORIES: '/admin/categories',
  ADMIN_ANALYTICS: '/admin/analytics'
};

// Query Keys for React Query
export const QUERY_KEYS = {
  // Auth
  AUTH_USER: 'auth-user',
  
  // Posts
  POSTS: 'posts',
  POST: 'post',
  POST_BY_SLUG: 'post-by-slug',
  MY_POSTS: 'my-posts',
  TRENDING_POSTS: 'trending-posts',
  FEATURED_POSTS: 'featured-posts',
  
  // Comments
  COMMENTS: 'comments',
  COMMENT: 'comment',
  
  // Categories
  CATEGORIES: 'categories',
  CATEGORY: 'category',
  
  // Users
  USERS: 'users',
  USER: 'user',
  USER_PROFILE: 'user-profile',
  
  // Admin
  ADMIN_STATS: 'admin-stats',
  ADMIN_USERS: 'admin-users',
  ADMIN_POSTS: 'admin-posts',
  ADMIN_COMMENTS: 'admin-comments'
};

// Cache Times (in milliseconds)
export const CACHE_TIME = {
  SHORT: 1 * 60 * 1000, // 1 minute
  MEDIUM: 5 * 60 * 1000, // 5 minutes
  LONG: 15 * 60 * 1000, // 15 minutes
  VERY_LONG: 60 * 60 * 1000 // 1 hour
};

// Pagination
export const PAGINATION = {
  DEFAULT_PAGE: 1,
  DEFAULT_LIMIT: Number(import.meta.env.VITE_DEFAULT_PAGE_SIZE) || 12,
  MAX_LIMIT: Number(import.meta.env.VITE_MAX_PAGE_SIZE) || 100
};

// File Upload
export const FILE_UPLOAD = {
  MAX_SIZE: Number(import.meta.env.VITE_MAX_FILE_SIZE) || 5242880, // 5MB
  ALLOWED_TYPES: (import.meta.env.VITE_ALLOWED_FILE_TYPES || 'image/jpeg,image/jpg,image/png,image/gif,image/webp').split(','),
  ACCEPTED_FORMATS: {
    'image/jpeg': ['.jpg', '.jpeg'],
    'image/png': ['.png'],
    'image/gif': ['.gif'],
    'image/webp': ['.webp']
  }
};

// Local Storage Keys
export const STORAGE_KEYS = {
  THEME: 'blog-theme',
  SIDEBAR_COLLAPSED: 'sidebar-collapsed',
  RECENT_SEARCHES: 'recent-searches',
  DRAFT_POST: 'draft-post'
};

// Theme
export const THEME = {
  LIGHT: 'light',
  DARK: 'dark',
  SYSTEM: 'system'
};

// Toast Duration
export const TOAST_DURATION = {
  SHORT: 2000,
  MEDIUM: 3000,
  LONG: 5000
};

// Debounce Delays
export const DEBOUNCE_DELAY = {
  SEARCH: 500,
  INPUT: 300,
  RESIZE: 150
};

// Validation Messages
export const VALIDATION_MESSAGES = {
  REQUIRED: 'This field is required',
  EMAIL: 'Please enter a valid email address',
  PASSWORD_MIN: 'Password must be at least 8 characters',
  PASSWORD_MATCH: 'Passwords do not match',
  USERNAME_MIN: 'Username must be at least 3 characters',
  TITLE_MIN: 'Title must be at least 5 characters',
  CONTENT_MIN: 'Content must be at least 50 characters',
  FILE_TOO_LARGE: 'File size exceeds 5MB limit',
  INVALID_FILE_TYPE: 'Invalid file type'
};

// Sort Options
export const SORT_OPTIONS = {
  LATEST: '-createdAt',
  OLDEST: 'createdAt',
  MOST_LIKED: '-likesCount',
  MOST_VIEWED: '-viewsCount',
  TITLE_ASC: 'title',
  TITLE_DESC: '-title'
};

// HTTP Status Codes
export const HTTP_STATUS = {
  OK: 200,
  CREATED: 201,
  NO_CONTENT: 204,
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  CONFLICT: 409,
  UNPROCESSABLE_ENTITY: 422,
  TOO_MANY_REQUESTS: 429,
  INTERNAL_SERVER_ERROR: 500,
  SERVICE_UNAVAILABLE: 503
};

// Error Messages
export const ERROR_MESSAGES = {
  NETWORK_ERROR: 'Network error. Please check your connection.',
  UNAUTHORIZED: 'You are not authorized to perform this action.',
  SESSION_EXPIRED: 'Your session has expired. Please login again.',
  SERVER_ERROR: 'Something went wrong. Please try again later.',
  NOT_FOUND: 'The requested resource was not found.',
  VALIDATION_ERROR: 'Please check your input and try again.'
};

// Success Messages
export const SUCCESS_MESSAGES = {
  LOGIN: 'Login successful!',
  LOGOUT: 'Logout successful!',
  REGISTER: 'Registration successful! Please check your email.',
  POST_CREATED: 'Post created successfully!',
  POST_UPDATED: 'Post updated successfully!',
  POST_DELETED: 'Post deleted successfully!',
  COMMENT_CREATED: 'Comment added successfully!',
  PROFILE_UPDATED: 'Profile updated successfully!',
  PASSWORD_CHANGED: 'Password changed successfully!'
};

// Date Formats
export const DATE_FORMATS = {
  FULL: 'MMMM DD, YYYY',
  SHORT: 'MMM DD, YYYY',
  TIME: 'hh:mm A',
  DATETIME: 'MMM DD, YYYY hh:mm A',
  RELATIVE: 'relative'
};

// Editor Config
export const EDITOR_CONFIG = {
  TOOLBAR_OPTIONS: [
    [{ header: [1, 2, 3, false] }],
    ['bold', 'italic', 'underline', 'strike'],
    [{ list: 'ordered' }, { list: 'bullet' }],
    [{ indent: '-1' }, { indent: '+1' }],
    ['link', 'image', 'code-block'],
    [{ align: [] }],
    ['clean']
  ],
  FORMATS: [
    'header',
    'bold',
    'italic',
    'underline',
    'strike',
    'list',
    'bullet',
    'indent',
    'link',
    'image',
    'code-block',
    'align'
  ]
};

// Animation Variants (Framer Motion)
export const ANIMATION_VARIANTS = {
  fadeIn: {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 }
  },
  slideUp: {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: 20 }
  },
  slideDown: {
    initial: { opacity: 0, y: -20 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -20 }
  },
  slideInLeft: {
    initial: { opacity: 0, x: -20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: -20 }
  },
  slideInRight: {
    initial: { opacity: 0, x: 20 },
    animate: { opacity: 1, x: 0 },
    exit: { opacity: 0, x: 20 }
  },
  scaleIn: {
    initial: { opacity: 0, scale: 0.9 },
    animate: { opacity: 1, scale: 1 },
    exit: { opacity: 0, scale: 0.9 }
  }
};
