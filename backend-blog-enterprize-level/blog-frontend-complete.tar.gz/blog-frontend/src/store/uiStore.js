import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { STORAGE_KEYS } from '@constants';

const useUIStore = create(
  persist(
    (set, get) => ({
      // Sidebar state
      sidebarCollapsed: false,
      sidebarOpen: true, // For mobile
      
      // Modal states
      activeModal: null,
      modalData: null,
      
      // Loading states
      globalLoading: false,
      
      // Mobile menu
      mobileMenuOpen: false,
      
      // Actions
      toggleSidebar: () => {
        set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed }));
      },
      
      setSidebarCollapsed: (collapsed) => {
        set({ sidebarCollapsed: collapsed });
      },
      
      setSidebarOpen: (open) => {
        set({ sidebarOpen: open });
      },
      
      openModal: (modalName, data = null) => {
        set({ activeModal: modalName, modalData: data });
      },
      
      closeModal: () => {
        set({ activeModal: null, modalData: null });
      },
      
      setGlobalLoading: (loading) => {
        set({ globalLoading: loading });
      },
      
      toggleMobileMenu: () => {
        set((state) => ({ mobileMenuOpen: !state.mobileMenuOpen }));
      },
      
      setMobileMenuOpen: (open) => {
        set({ mobileMenuOpen: open });
      },
      
      // Getters
      isSidebarCollapsed: () => get().sidebarCollapsed,
      isSidebarOpen: () => get().sidebarOpen,
      isModalOpen: (modalName) => get().activeModal === modalName,
      getModalData: () => get().modalData
    }),
    {
      name: STORAGE_KEYS.SIDEBAR_COLLAPSED,
      partialize: (state) => ({
        sidebarCollapsed: state.sidebarCollapsed
      })
    }
  )
);

export default useUIStore;
