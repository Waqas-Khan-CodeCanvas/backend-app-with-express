import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { THEME, STORAGE_KEYS } from '@constants';

const useThemeStore = create(
  persist(
    (set, get) => ({
      // State
      theme: THEME.LIGHT,
      
      // Actions
      setTheme: (theme) => {
        set({ theme });
        applyTheme(theme);
      },
      
      toggleTheme: () => {
        const currentTheme = get().theme;
        const newTheme = currentTheme === THEME.LIGHT ? THEME.DARK : THEME.LIGHT;
        set({ theme: newTheme });
        applyTheme(newTheme);
      },
      
      // Getters
      isDark: () => get().theme === THEME.DARK
    }),
    {
      name: STORAGE_KEYS.THEME
    }
  )
);

// Apply theme to DOM
const applyTheme = (theme) => {
  const root = window.document.documentElement;
  
  if (theme === THEME.DARK) {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }
};

// Initialize theme on load
if (typeof window !== 'undefined') {
  const storedTheme = localStorage.getItem(STORAGE_KEYS.THEME);
  if (storedTheme) {
    try {
      const { state } = JSON.parse(storedTheme);
      applyTheme(state.theme);
    } catch (e) {
      applyTheme(THEME.LIGHT);
    }
  }
}

export default useThemeStore;
