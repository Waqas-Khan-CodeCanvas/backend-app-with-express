import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useAuthStore = create(
  persist(
    (set, get) => ({
      // State
      user: null,
      accessToken: null,
      isAuthenticated: false,
      isLoading: false,
      
      // Actions
      setUser: (user) => {
        set({ user, isAuthenticated: !!user });
      },
      
      setAccessToken: (token) => {
        set({ accessToken: token });
        // Store in global variable for API interceptor
        window.__ACCESS_TOKEN__ = token;
      },
      
      setAuth: (user, accessToken) => {
        set({ 
          user, 
          accessToken, 
          isAuthenticated: true 
        });
        window.__ACCESS_TOKEN__ = accessToken;
      },
      
      updateUser: (updates) => {
        set((state) => ({
          user: state.user ? { ...state.user, ...updates } : null
        }));
      },
      
      logout: () => {
        set({ 
          user: null, 
          accessToken: null, 
          isAuthenticated: false 
        });
        window.__ACCESS_TOKEN__ = null;
      },
      
      setLoading: (isLoading) => {
        set({ isLoading });
      },
      
      // Getters
      getUser: () => get().user,
      getAccessToken: () => get().accessToken,
      isAdmin: () => get().user?.role === 'admin',
      isModerator: () => ['admin', 'moderator'].includes(get().user?.role),
      isAuthor: () => ['admin', 'moderator', 'author'].includes(get().user?.role),
      canEdit: (resourceUserId) => {
        const currentUser = get().user;
        if (!currentUser) return false;
        if (currentUser.role === 'admin') return true;
        return currentUser.id === resourceUserId || currentUser._id === resourceUserId;
      }
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        user: state.user,
        accessToken: state.accessToken,
        isAuthenticated: state.isAuthenticated
      }),
      onRehydrateStorage: () => (state) => {
        if (state?.accessToken) {
          window.__ACCESS_TOKEN__ = state.accessToken;
        }
      }
    }
  )
);

// Setup global handlers for API service
window.__UPDATE_AUTH_TOKEN__ = (token) => {
  useAuthStore.getState().setAccessToken(token);
};

window.__HANDLE_LOGOUT__ = () => {
  useAuthStore.getState().logout();
  // Clear all cached data
  if (window.location.pathname !== '/login') {
    window.location.href = '/login?expired=true';
  }
};

export default useAuthStore;
