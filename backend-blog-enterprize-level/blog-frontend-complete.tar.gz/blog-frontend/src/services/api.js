import axios from 'axios';
import { API_CONFIG, HTTP_STATUS, ERROR_MESSAGES } from '@constants';

// Create axios instance
const api = axios.create({
  baseURL: API_CONFIG.BASE_URL,
  timeout: API_CONFIG.TIMEOUT,
  withCredentials: true, // Important for cookies (refresh token)
  headers: {
    'Content-Type': 'application/json'
  }
});

// Request interceptor
api.interceptors.request.use(
  (config) => {
    // Get access token from memory/store (managed by Zustand)
    const accessToken = window.__ACCESS_TOKEN__;
    
    if (accessToken) {
      config.headers.Authorization = `Bearer ${accessToken}`;
    }
    
    // Log request in development
    if (import.meta.env.DEV) {
      console.log(`[API Request] ${config.method.toUpperCase()} ${config.url}`, config.data);
    }
    
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor
let isRefreshing = false;
let failedQueue = [];

const processQueue = (error, token = null) => {
  failedQueue.forEach(prom => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(token);
    }
  });
  
  failedQueue = [];
};

api.interceptors.response.use(
  (response) => {
    // Log response in development
    if (import.meta.env.DEV) {
      console.log(`[API Response] ${response.config.method.toUpperCase()} ${response.config.url}`, response.data);
    }
    
    return response;
  },
  async (error) => {
    const originalRequest = error.config;
    
    // Log error in development
    if (import.meta.env.DEV) {
      console.error('[API Error]', error);
    }
    
    // Handle network errors
    if (!error.response) {
      return Promise.reject({
        message: ERROR_MESSAGES.NETWORK_ERROR,
        status: 0
      });
    }
    
    const { status } = error.response;
    
    // Handle 401 Unauthorized - Token expired
    if (status === HTTP_STATUS.UNAUTHORIZED && !originalRequest._retry) {
      if (isRefreshing) {
        // Queue the request
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        })
          .then(token => {
            originalRequest.headers.Authorization = `Bearer ${token}`;
            return api(originalRequest);
          })
          .catch(err => {
            return Promise.reject(err);
          });
      }
      
      originalRequest._retry = true;
      isRefreshing = true;
      
      try {
        // Call refresh token endpoint
        const { data } = await axios.post(
          `${API_CONFIG.BASE_URL}/auth/refresh`,
          {},
          { withCredentials: true }
        );
        
        const newAccessToken = data.data.accessToken;
        
        // Update global access token
        window.__ACCESS_TOKEN__ = newAccessToken;
        
        // Update auth store (will be imported dynamically to avoid circular dependency)
        if (window.__UPDATE_AUTH_TOKEN__) {
          window.__UPDATE_AUTH_TOKEN__(newAccessToken);
        }
        
        // Process queued requests
        processQueue(null, newAccessToken);
        
        // Retry original request
        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
        return api(originalRequest);
      } catch (refreshError) {
        processQueue(refreshError, null);
        
        // Clear tokens and redirect to login
        window.__ACCESS_TOKEN__ = null;
        
        if (window.__HANDLE_LOGOUT__) {
          window.__HANDLE_LOGOUT__();
        }
        
        return Promise.reject({
          message: ERROR_MESSAGES.SESSION_EXPIRED,
          status: HTTP_STATUS.UNAUTHORIZED
        });
      } finally {
        isRefreshing = false;
      }
    }
    
    // Handle 403 Forbidden
    if (status === HTTP_STATUS.FORBIDDEN) {
      return Promise.reject({
        message: error.response?.data?.message || ERROR_MESSAGES.UNAUTHORIZED,
        status
      });
    }
    
    // Handle 404 Not Found
    if (status === HTTP_STATUS.NOT_FOUND) {
      return Promise.reject({
        message: error.response?.data?.message || ERROR_MESSAGES.NOT_FOUND,
        status
      });
    }
    
    // Handle 422 Validation Error
    if (status === HTTP_STATUS.UNPROCESSABLE_ENTITY) {
      return Promise.reject({
        message: error.response?.data?.message || ERROR_MESSAGES.VALIDATION_ERROR,
        errors: error.response?.data?.errors || [],
        status
      });
    }
    
    // Handle 429 Too Many Requests
    if (status === HTTP_STATUS.TOO_MANY_REQUESTS) {
      return Promise.reject({
        message: error.response?.data?.message || 'Too many requests. Please try again later.',
        status
      });
    }
    
    // Handle 500+ Server Errors
    if (status >= HTTP_STATUS.INTERNAL_SERVER_ERROR) {
      return Promise.reject({
        message: ERROR_MESSAGES.SERVER_ERROR,
        status
      });
    }
    
    // Default error handling
    return Promise.reject({
      message: error.response?.data?.message || error.message || ERROR_MESSAGES.SERVER_ERROR,
      status: error.response?.status || 500
    });
  }
);

// API Helper Methods
export const apiClient = {
  get: (url, config) => api.get(url, config),
  post: (url, data, config) => api.post(url, data, config),
  put: (url, data, config) => api.put(url, data, config),
  patch: (url, data, config) => api.patch(url, data, config),
  delete: (url, config) => api.delete(url, config)
};

// Upload file helper
export const uploadFile = async (url, file, onUploadProgress) => {
  const formData = new FormData();
  formData.append('image', file);
  
  return api.post(url, formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    },
    onUploadProgress
  });
};

export default api;
