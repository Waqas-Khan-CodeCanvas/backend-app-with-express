# 🚀 Production-Ready React Blog Frontend

## Enterprise-Grade React Application

A complete, scalable frontend built with modern React ecosystem that connects to your Express.js + MongoDB backend.

---

## ✨ Tech Stack

- **React 18+** - Latest React with concurrent features
- **Vite** - Lightning-fast build tool
- **Tailwind CSS** - Utility-first CSS framework
- **React Router v6** - Client-side routing
- **Axios** - HTTP client with interceptors
- **TanStack Query (React Query)** - Server state management
- **Zustand** - Client state management
- **React Hook Form** - Form management
- **Zod** - Schema validation
- **Framer Motion** - Animations
- **React Hot Toast** - Toast notifications
- **React Icons** - Icon library
- **DayJS** - Date formatting
- **React Quill** - Rich text editor
- **DOMPurify** - HTML sanitization

---

## 📁 Project Structure

```
src/
├── app/
│   ├── App.jsx                 # Main app component
│   └── router.jsx              # Route configuration
├── assets/                     # Static assets
├── components/
│   ├── ui/                     # Reusable UI components
│   │   ├── Button.jsx
│   │   ├── Input.jsx
│   │   ├── Modal.jsx
│   │   ├── Card.jsx
│   │   ├── Badge.jsx
│   │   ├── Dropdown.jsx
│   │   └── ...
│   ├── layout/                 # Layout components
│   │   ├── Navbar.jsx
│   │   ├── Sidebar.jsx
│   │   ├── Footer.jsx
│   │   └── DashboardLayout.jsx
│   └── shared/                 # Shared components
│       ├── LoadingSpinner.jsx
│       ├── ErrorBoundary.jsx
│       ├── ProtectedRoute.jsx
│       └── ...
├── features/
│   ├── auth/
│   │   ├── api.js             # Auth API calls
│   │   ├── hooks.js           # Auth React Query hooks
│   │   ├── store.js           # Auth Zustand store
│   │   ├── pages/
│   │   │   ├── LoginPage.jsx
│   │   │   ├── RegisterPage.jsx
│   │   │   ├── ForgotPasswordPage.jsx
│   │   │   └── ResetPasswordPage.jsx
│   │   └── components/
│   │       ├── LoginForm.jsx
│   │       └── RegisterForm.jsx
│   ├── posts/
│   │   ├── api.js
│   │   ├── hooks.js
│   │   ├── pages/
│   │   │   ├── PostsPage.jsx
│   │   │   ├── PostDetailPage.jsx
│   │   │   ├── CreatePostPage.jsx
│   │   │   └── EditPostPage.jsx
│   │   └── components/
│   │       ├── PostCard.jsx
│   │       ├── PostList.jsx
│   │       ├── PostEditor.jsx
│   │       └── CommentSection.jsx
│   ├── comments/
│   │   ├── api.js
│   │   ├── hooks.js
│   │   └── components/
│   ├── categories/
│   │   ├── api.js
│   │   ├── hooks.js
│   │   └── pages/
│   └── admin/
│       ├── api.js
│       ├── hooks.js
│       ├── pages/
│       │   ├── DashboardPage.jsx
│       │   ├── UsersPage.jsx
│       │   ├── PostsManagementPage.jsx
│       │   └── CommentsManagementPage.jsx
│       └── components/
│           ├── StatCard.jsx
│           └── DataTable.jsx
├── hooks/
│   ├── useDebounce.js
│   ├── useLocalStorage.js
│   ├── useMediaQuery.js
│   └── usePagination.js
├── services/
│   └── api.js                 # Axios instance with interceptors
├── store/
│   ├── authStore.js           # Auth state
│   ├── themeStore.js          # Theme state
│   └── uiStore.js             # UI state
├── utils/
│   └── index.js               # Utility functions
├── constants/
│   └── index.js               # App constants
├── lib/
│   └── queryClient.js         # React Query config
└── styles/
    └── index.css              # Global styles
```

---

## 🚀 Quick Start

### Prerequisites

- Node.js >= 18.0.0
- npm >= 9.0.0
- Backend API running on `http://localhost:5000`

### Installation

1. **Install dependencies**
```bash
npm install
```

2. **Configure environment**
```bash
cp .env.example .env
```

Edit `.env`:
```env
VITE_API_BASE_URL=http://localhost:5000/api/v1
VITE_NODE_ENV=development
```

3. **Start development server**
```bash
npm run dev
```

App will run on `http://localhost:3000`

4. **Build for production**
```bash
npm run build
npm run preview
```

---

## 🔐 Authentication Flow

### Features Implemented

- ✅ Register with email verification
- ✅ Login with JWT access token
- ✅ Refresh token rotation (HTTP-only cookie)
- ✅ Logout with token invalidation
- ✅ Forgot password
- ✅ Reset password with secure token
- ✅ Protected routes
- ✅ Role-based access control
- ✅ Auto token refresh on 401
- ✅ Session persistence
- ✅ Account lockout after failed attempts

### Token Management

- **Access Token**: Stored in memory (Zustand store)
- **Refresh Token**: HTTP-only cookie (handled by backend)
- **Auto Refresh**: Axios interceptor handles 401 and refreshes automatically
- **Logout**: Clears both tokens

### Route Protection

```javascript
// Public routes
/ - Home
/posts - All posts
/posts/:slug - Post detail
/login - Login
/register - Register

// Protected routes (require auth)
/profile - User profile
/posts/create - Create post
/posts/:id/edit - Edit post

// Admin routes (require admin role)
/admin/* - Admin panel
```

---

## 📝 Features Overview

### Public Features

1. **Homepage**
   - Latest posts
   - Trending posts
   - Featured posts
   - Category filters
   - Tag cloud
   - Search with debounce

2. **Posts**
   - List view with pagination
   - Grid view
   - Filter by category/tag
   - Sort by date/likes/views
   - Full-text search
   - Post detail page
   - Related posts
   - Reading time

3. **Authors**
   - Author profile page
   - Author's posts
   - Social links

### User Features

1. **Post Management**
   - Create post with rich text editor
   - Upload cover image
   - Save as draft
   - Preview before publish
   - Edit/delete own posts
   - Post analytics

2. **Engagement**
   - Like/unlike posts
   - Comment on posts
   - Reply to comments
   - Edit/delete own comments
   - Report inappropriate content

3. **Profile**
   - Edit profile
   - Upload profile image
   - View own posts
   - Change password
   - Account settings

### Admin Features

1. **Dashboard**
   - Statistics overview
   - Recent activities
   - Charts and graphs

2. **User Management**
   - List all users
   - Filter by role
   - Ban/unban users
   - View user activity

3. **Content Moderation**
   - Approve/reject posts
   - Moderate comments
   - Mark as spam
   - Bulk actions

4. **Category Management**
   - Create/edit categories
   - Organize hierarchy
   - Assign colors/icons

---

## 🎨 UI Components

### Reusable Components

```javascript
// Button variants
<Button variant="primary">Primary</Button>
<Button variant="secondary">Secondary</Button>
<Button variant="outline">Outline</Button>
<Button variant="ghost">Ghost</Button>
<Button variant="danger">Danger</Button>

// Input types
<Input type="text" />
<Input type="email" />
<Input type="password" />
<Textarea />

// Modal
<Modal isOpen={isOpen} onClose={onClose}>
  <Modal.Header>Title</Modal.Header>
  <Modal.Body>Content</Modal.Body>
  <Modal.Footer>Actions</Modal.Footer>
</Modal>

// Card
<Card>
  <Card.Header>Header</Card.Header>
  <Card.Body>Body</Card.Body>
  <Card.Footer>Footer</Card.Footer>
</Card>

// Badge
<Badge variant="success">Success</Badge>
<Badge variant="danger">Danger</Badge>

// Dropdown
<Dropdown>
  <Dropdown.Item>Item 1</Dropdown.Item>
  <Dropdown.Item>Item 2</Dropdown.Item>
</Dropdown>
```

### Layout Components

- **Navbar**: Top navigation with user menu
- **Sidebar**: Collapsible sidebar for admin
- **Footer**: Site footer with links
- **DashboardLayout**: Admin layout wrapper

---

## 🔄 State Management

### Zustand Stores

**Auth Store** (`authStore.js`)
```javascript
{
  user: null,
  accessToken: null,
  isAuthenticated: false,
  setAuth: (user, token) => {...},
  logout: () => {...}
}
```

**Theme Store** (`themeStore.js`)
```javascript
{
  theme: 'light',
  setTheme: (theme) => {...},
  toggleTheme: () => {...}
}
```

**UI Store** (`uiStore.js`)
```javascript
{
  sidebarCollapsed: false,
  activeModal: null,
  toggleSidebar: () => {...},
  openModal: (name) => {...}
}
```

### React Query

**Caching Strategy**
- Posts: 5 minutes
- Categories: 15 minutes
- User profile: 1 minute
- Admin stats: 30 seconds

**Automatic Features**
- Background refetching
- Optimistic updates
- Infinite scroll
- Pagination
- Retry on failure

---

## 🛡️ Security Features

1. **XSS Protection**
   - DOMPurify sanitizes all HTML
   - Safe innerHTML rendering

2. **Token Management**
   - Access token in memory (Zustand)
   - Refresh token in HTTP-only cookie
   - No localStorage for sensitive data

3. **Input Validation**
   - Zod schema validation
   - React Hook Form integration
   - Server-side validation backup

4. **Error Boundaries**
   - Catch React errors
   - Fallback UI
   - Error logging

5. **CORS**
   - Configured for backend origin
   - Credentials included

---

## ⚡ Performance Optimization

1. **Code Splitting**
   - Route-based lazy loading
   - Component lazy loading
   - Dynamic imports

2. **Image Optimization**
   - Lazy loading images
   - Cloudinary CDN
   - Responsive images

3. **Caching**
   - React Query cache
   - Browser cache headers
   - Service worker (PWA ready)

4. **Bundle Optimization**
   - Vite tree-shaking
   - Manual chunks
   - Compression

5. **Performance Monitoring**
   - Web Vitals
   - Lighthouse scores
   - Bundle analysis

---

## 🧪 Testing

### Unit Tests
```bash
npm test
```

### Coverage
```bash
npm run test:coverage
```

### Test Structure
```
tests/
├── unit/
│   ├── components/
│   ├── hooks/
│   └── utils/
├── integration/
│   └── features/
└── e2e/
    └── flows/
```

---

## 📦 Build & Deployment

### Development
```bash
npm run dev
```

### Production Build
```bash
npm run build
```

### Preview Build
```bash
npm run preview
```

### Deploy to Vercel
```bash
vercel --prod
```

### Deploy to Netlify
```bash
netlify deploy --prod
```

### Environment Variables

Production `.env`:
```env
VITE_API_BASE_URL=https://api.yourdomain.com/api/v1
VITE_NODE_ENV=production
VITE_ENABLE_ANALYTICS=true
```

---

## 🎨 Theming

### Dark Mode

Toggle dark mode:
```javascript
const { theme, toggleTheme } = useThemeStore();

<button onClick={toggleTheme}>
  {theme === 'dark' ? <Sun /> : <Moon />}
</button>
```

### Custom Colors

Edit `tailwind.config.js`:
```javascript
colors: {
  primary: {
    500: '#3B82F6',
    // ...
  }
}
```

---

## 🔌 API Integration

### API Service (`services/api.js`)

Features:
- Axios instance
- Request interceptor (add auth token)
- Response interceptor (handle errors, refresh token)
- Auto retry on failure
- Error normalization

### Feature APIs

Each feature has its own API file:
- `features/auth/api.js` - Authentication
- `features/posts/api.js` - Posts CRUD
- `features/comments/api.js` - Comments
- `features/admin/api.js` - Admin operations

---

## 📱 Responsive Design

- **Mobile First**: Designed for mobile, enhanced for desktop
- **Breakpoints**:
  - sm: 640px
  - md: 768px
  - lg: 1024px
  - xl: 1280px
  - 2xl: 1536px

- **Mobile Menu**: Hamburger menu for navigation
- **Responsive Grid**: Auto-adjusting post cards
- **Touch Gestures**: Swipe support

---

## 🚀 Advanced Features

1. **Rich Text Editor**
   - React Quill integration
   - Image upload
   - Code blocks
   - Link insertion

2. **File Upload**
   - Drag & drop
   - Image preview
   - Progress bar
   - Size validation

3. **Infinite Scroll**
   - Auto-load more posts
   - Intersection Observer
   - Loading skeletons

4. **Search**
   - Debounced search
   - Recent searches
   - Search suggestions

5. **Notifications**
   - Toast notifications
   - Real-time updates (ready for WebSocket)

---

## 🐛 Troubleshooting

### Common Issues

**API Connection Failed**
- Check backend is running on port 5000
- Verify VITE_API_BASE_URL in .env

**Authentication Not Working**
- Clear browser cookies
- Check token expiration
- Verify backend JWT secrets

**Build Errors**
- Delete node_modules and reinstall
- Clear Vite cache: `rm -rf node_modules/.vite`

---

## 📄 License

MIT License

---

## 👨‍💻 Development

This is a production-ready codebase following best practices:
- Clean code architecture
- SOLID principles
- DRY (Don't Repeat Yourself)
- Component composition
- Custom hooks
- Error boundaries
- Type checking ready (migration path to TypeScript)

Built for scalability and maintainability! 🚀
