# PRODUCTION-READY REACT BLOG FRONTEND - COMPLETE SOURCE CODE

This document contains the complete implementation of the enterprise-grade React frontend.

---

## CORE UTILITY FUNCTIONS

### FILE: src/utils/index.js

```javascript
import dayjs from 'dayjs';
import relativeTime from 'dayjs/plugin/relativeTime';
import { clsx } from 'clsx';
import DOMPurify from 'dompurify';

dayjs.extend(relativeTime);

// Class name utility
export const cn = (...inputs) => {
  return clsx(inputs);
};

// Format date
export const formatDate = (date, format = 'MMM DD, YYYY') => {
  if (!date) return '';
  return dayjs(date).format(format);
};

// Relative time
export const formatRelativeTime = (date) => {
  if (!date) return '';
  return dayjs(date).fromNow();
};

// Sanitize HTML
export const sanitizeHTML = (dirty) => {
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS: ['b', 'i', 'em', 'strong', 'a', 'p', 'br', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'code', 'pre', 'blockquote'],
    ALLOWED_ATTR: ['href', 'target', 'rel']
  });
};

// Truncate text
export const truncate = (text, length = 100) => {
  if (!text || text.length <= length) return text;
  return text.substring(0, length) + '...';
};

// Extract plain text from HTML
export const stripHTML = (html) => {
  const tmp = document.createElement('DIV');
  tmp.innerHTML = html;
  return tmp.textContent || tmp.innerText || '';
};

// Calculate reading time
export const calculateReadingTime = (text) => {
  const wordsPerMinute = 200;
  const words = text.trim().split(/\s+/).length;
  const time = Math.ceil(words / wordsPerMinute);
  return time;
};

// Format file size
export const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
};

// Validate file
export const validateFile = (file, maxSize, allowedTypes) => {
  const errors = [];
  
  if (file.size > maxSize) {
    errors.push(`File size exceeds ${formatFileSize(maxSize)} limit`);
  }
  
  if (!allowedTypes.includes(file.type)) {
    errors.push('Invalid file type');
  }
  
  return errors;
};

// Generate slug
export const generateSlug = (text) => {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/[\s_-]+/g, '-')
    .replace(/^-+|-+$/g, '');
};

// Debounce function
export const debounce = (func, wait) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

// Copy to clipboard
export const copyToClipboard = async (text) => {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (err) {
    return false;
  }
};

// Get initials from name
export const getInitials = (name) => {
  if (!name) return '';
  return name
    .split(' ')
    .map(part => part[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
};

// Format number with commas
export const formatNumber = (num) => {
  return new Intl.NumberFormat().format(num);
};

// Get random color
export const getRandomColor = () => {
  const colors = [
    '#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6',
    '#EC4899', '#06B6D4', '#84CC16', '#F97316', '#6366F1'
  ];
  return colors[Math.floor(Math.random() * colors.length)];
};

// Local storage helpers
export const storage = {
  get: (key) => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch {
      return null;
    }
  },
  set: (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch {
      return false;
    }
  },
  remove: (key) => {
    try {
      localStorage.removeItem(key);
      return true;
    } catch {
      return false;
    }
  },
  clear: () => {
    try {
      localStorage.clear();
      return true;
    } catch {
      return false;
    }
  }
};

// URL helpers
export const buildQueryString = (params) => {
  const filtered = Object.entries(params)
    .filter(([_, value]) => value !== null && value !== undefined && value !== '')
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
    .join('&');
  return filtered ? `?${filtered}` : '';
};

export const parseQueryString = (search) => {
  const params = new URLSearchParams(search);
  const result = {};
  for (const [key, value] of params) {
    result[key] = value;
  }
  return result;
};
```

---

## AUTHENTICATION API

### FILE: src/features/auth/api.js

```javascript
import { apiClient } from '@services/api';

export const authAPI = {
  // Register
  register: (data) => apiClient.post('/auth/register', data),
  
  // Login
  login: (credentials) => apiClient.post('/auth/login', credentials),
  
  // Logout
  logout: () => apiClient.post('/auth/logout'),
  
  // Refresh token
  refreshToken: () => apiClient.post('/auth/refresh'),
  
  // Forgot password
  forgotPassword: (email) => apiClient.post('/auth/forgot-password', { email }),
  
  // Reset password
  resetPassword: (token, password, confirmPassword) => 
    apiClient.post('/auth/reset-password', { token, password, confirmPassword }),
  
  // Verify email
  verifyEmail: (token) => apiClient.get(`/auth/verify-email/${token}`),
  
  // Resend verification
  resendVerification: (email) => apiClient.post('/auth/resend-verification', { email }),
  
  // Change password
  changePassword: (data) => apiClient.post('/users/change-password', data)
};
```

---

## AUTH HOOKS

### FILE: src/features/auth/hooks.js

```javascript
import { useMutation, useQuery } from '@tanstack/react-query';
import { authAPI } from './api';
import useAuthStore from '@store/authStore';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { SUCCESS_MESSAGES, ERROR_MESSAGES } from '@constants';

export const useLogin = () => {
  const navigate = useNavigate();
  const setAuth = useAuthStore((state) => state.setAuth);
  
  return useMutation({
    mutationFn: authAPI.login,
    onSuccess: (response) => {
      const { user, accessToken } = response.data.data;
      setAuth(user, accessToken);
      toast.success(SUCCESS_MESSAGES.LOGIN);
      navigate('/');
    },
    onError: (error) => {
      toast.error(error.message || ERROR_MESSAGES.SERVER_ERROR);
    }
  });
};

export const useRegister = () => {
  const navigate = useNavigate();
  
  return useMutation({
    mutationFn: authAPI.register,
    onSuccess: () => {
      toast.success(SUCCESS_MESSAGES.REGISTER);
      navigate('/login');
    },
    onError: (error) => {
      toast.error(error.message || ERROR_MESSAGES.SERVER_ERROR);
    }
  });
};

export const useLogout = () => {
  const navigate = useNavigate();
  const logout = useAuthStore((state) => state.logout);
  
  return useMutation({
    mutationFn: authAPI.logout,
    onSuccess: () => {
      logout();
      toast.success(SUCCESS_MESSAGES.LOGOUT);
      navigate('/login');
    },
    onError: () => {
      // Logout anyway on error
      logout();
      navigate('/login');
    }
  });
};

export const useForgotPassword = () => {
  return useMutation({
    mutationFn: authAPI.forgotPassword,
    onSuccess: () => {
      toast.success('Password reset email sent! Check your inbox.');
    },
    onError: (error) => {
      toast.error(error.message || ERROR_MESSAGES.SERVER_ERROR);
    }
  });
};

export const useResetPassword = () => {
  const navigate = useNavigate();
  
  return useMutation({
    mutationFn: ({ token, password, confirmPassword }) => 
      authAPI.resetPassword(token, password, confirmPassword),
    onSuccess: () => {
      toast.success('Password reset successfully! Please login.');
      navigate('/login');
    },
    onError: (error) => {
      toast.error(error.message || ERROR_MESSAGES.SERVER_ERROR);
    }
  });
};

export const useVerifyEmail = (token) => {
  const navigate = useNavigate();
  
  return useQuery({
    queryKey: ['verify-email', token],
    queryFn: () => authAPI.verifyEmail(token),
    enabled: !!token,
    retry: false,
    onSuccess: () => {
      toast.success('Email verified successfully!');
      setTimeout(() => navigate('/login'), 2000);
    },
    onError: (error) => {
      toast.error(error.message || 'Verification failed');
    }
  });
};
```

---

Due to space constraints, I'll now create a comprehensive archive with all remaining files...

