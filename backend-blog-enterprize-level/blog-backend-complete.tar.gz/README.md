# Production-Ready Blog Backend API

## 🚀 Complete Enterprise-Grade Blog Platform

### Project Overview
A fully-featured, production-ready blog backend with advanced features including authentication, authorization, file uploads, email system, caching, rate limiting, and comprehensive admin panel.

## ✨ Features Implemented

### Core Features
- ✅ JWT Authentication with refresh token rotation
- ✅ Role-based access control (User, Author, Moderator, Admin)
- ✅ Email verification system
- ✅ Password reset with secure tokens
- ✅ OTP verification
- ✅ Redis caching for performance
- ✅ File upload with Cloudinary integration
- ✅ Advanced logging with Winston
- ✅ Rate limiting for security
- ✅ Input validation with Joi
- ✅ MongoDB with proper indexing
- ✅ Soft delete functionality
- ✅ CORS configuration
- ✅ Helmet security headers
- ✅ XSS protection
- ✅ MongoDB sanitization
- ✅ HTTP parameter pollution protection
- ✅ Compression middleware

### Blog Features
- ✅ Full CRUD operations for posts
- ✅ Draft/Published/Archived status
- ✅ Auto-generated slugs
- ✅ SEO meta fields
- ✅ Categories with hierarchical structure
- ✅ Tag system
- ✅ Featured images with Cloudinary
- ✅ Reading time calculation
- ✅ Post scheduling
- ✅ Like system
- ✅ View counter
- ✅ Full-text search
- ✅ Advanced filtering and sorting
- ✅ Pagination

### Comment System
- ✅ Nested comments (replies)
- ✅ Comment moderation (Pending/Approved/Rejected/Spam)
- ✅ Like comments
- ✅ Edit/Delete comments
- ✅ Report system
- ✅ Soft delete

### Admin Panel Features
- ✅ User management (ban/unban)
- ✅ Content moderation
- ✅ Analytics dashboard
- ✅ Bulk operations
- ✅ Activity logs

### Security Features
- ✅ Account lockout after failed login attempts
- ✅ CSRF protection ready
- ✅ Refresh token rotation
- ✅ Secure HTTP-only cookies
- ✅ Password hashing with bcrypt (12 rounds)
- ✅ Input sanitization
- ✅ Rate limiting per endpoint

## 📁 Project Structure

```
blog-backend/
├── src/
│   ├── config/
│   │   ├── db.js                    # MongoDB connection
│   │   ├── env.js                   # Environment variables
│   │   ├── logger.js                # Winston logger
│   │   ├── cors.js                  # CORS configuration
│   │   ├── redis.js                 # Redis client
│   │   └── cloudinary.js            # Cloudinary config
│   ├── constants/
│   │   └── index.js                 # App constants
│   ├── controllers/
│   │   ├── auth.controller.js       # Auth endpoints
│   │   ├── user.controller.js       # User management
│   │   ├── post.controller.js       # Post CRUD
│   │   ├── comment.controller.js    # Comment system
│   │   ├── category.controller.js   # Categories
│   │   └── admin.controller.js      # Admin panel
│   ├── middleware/
│   │   ├── auth.middleware.js       # JWT verification
│   │   ├── authorize.middleware.js  # Role checks
│   │   ├── validate.middleware.js   # Input validation
│   │   ├── error.middleware.js      # Error handler
│   │   ├── rateLimit.middleware.js  # Rate limiting
│   │   ├── upload.middleware.js     # File uploads
│   │   └── logger.middleware.js     # Request logging
│   ├── models/
│   │   ├── user.model.js            # User schema
│   │   ├── post.model.js            # Post schema
│   │   ├── comment.model.js         # Comment schema
│   │   └── category.model.js        # Category schema
│   ├── repositories/
│   │   ├── user.repository.js       # User DB layer
│   │   ├── post.repository.js       # Post DB layer
│   │   └── comment.repository.js    # Comment DB layer
│   ├── routes/
│   │   ├── index.js                 # Route aggregator
│   │   ├── auth.route.js            # Auth routes
│   │   ├── user.route.js            # User routes
│   │   ├── post.route.js            # Post routes
│   │   ├── comment.route.js         # Comment routes
│   │   ├── category.route.js        # Category routes
│   │   └── admin.route.js           # Admin routes
│   ├── services/
│   │   ├── auth.service.js          # Auth business logic
│   │   ├── user.service.js          # User operations
│   │   ├── post.service.js          # Post operations
│   │   ├── comment.service.js       # Comment operations
│   │   ├── email.service.js         # Email sender
│   │   └── upload.service.js        # File upload
│   ├── validators/
│   │   ├── auth.validator.js        # Auth validation
│   │   ├── user.validator.js        # User validation
│   │   ├── post.validator.js        # Post validation
│   │   └── comment.validator.js     # Comment validation
│   ├── utils/
│   │   ├── apiError.js              # Custom error class
│   │   ├── apiResponse.js           # Response formatter
│   │   ├── asyncHandler.js          # Async wrapper
│   │   ├── email.templates.js       # Email templates
│   │   └── helpers.js               # Utility functions
│   ├── docs/
│   │   └── swagger.js               # API documentation
│   ├── app.js                       # Express app
│   └── server.js                    # Server entry
├── tests/
│   ├── unit/
│   ├── integration/
│   └── e2e/
├── logs/
├── .env
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── nodemon.json
```

## 🔧 Installation & Setup

### Prerequisites
- Node.js >= 18.0.0
- MongoDB >= 5.0
- Redis >= 6.0
- Cloudinary account (for image uploads)
- SMTP server (for emails)

### Installation Steps

1. **Clone and Install Dependencies**
```bash
npm install
```

2. **Environment Configuration**
```bash
cp .env.example .env
# Edit .env with your configuration
```

3. **Start Services**
```bash
# Start MongoDB (if local)
mongod

# Start Redis (if local)
redis-server

# Development mode
npm run dev

# Production mode
npm start
```

## 📝 Environment Variables

See `.env.example` for all required variables. Key ones:

```env
NODE_ENV=development
PORT=5000
MONGODB_URI=mongodb://localhost:27017/blog_db
REDIS_HOST=localhost
REDIS_PORT=6379
JWT_ACCESS_TOKEN_SECRET_KEY=your-secret
JWT_REFRESH_TOKEN_SECRET_KEY=your-refresh-secret
CLOUDINARY_CLOUD_NAME=your-cloud
CLOUDINARY_API_KEY=your-key
CLOUDINARY_API_SECRET=your-secret
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

## 📚 API Documentation

### Authentication Endpoints

#### Register
```http
POST /api/v1/auth/register
Content-Type: application/json

{
  "username": "johndoe",
  "email": "john@example.com",
  "password": "SecurePass123!",
  "confirmPassword": "SecurePass123!",
  "firstName": "John",
  "lastName": "Doe"
}
```

#### Login
```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "SecurePass123!"
}
```

#### Refresh Token
```http
POST /api/v1/auth/refresh
Cookie: refreshToken=<token>
```

#### Logout
```http
POST /api/v1/auth/logout
Authorization: Bearer <accessToken>
```

#### Forgot Password
```http
POST /api/v1/auth/forgot-password
Content-Type: application/json

{
  "email": "john@example.com"
}
```

#### Reset Password
```http
POST /api/v1/auth/reset-password
Content-Type: application/json

{
  "token": "reset-token",
  "password": "NewSecurePass123!",
  "confirmPassword": "NewSecurePass123!"
}
```

#### Verify Email
```http
GET /api/v1/auth/verify-email/:token
```

#### Resend Verification Email
```http
POST /api/v1/auth/resend-verification
Content-Type: application/json

{
  "email": "john@example.com"
}
```

### Post Endpoints

#### Get All Posts (Public)
```http
GET /api/v1/posts?page=1&limit=10&sort=-createdAt&status=published&search=keyword&category=categoryId&tag=tagName
```

#### Get Single Post (Public)
```http
GET /api/v1/posts/:id
# or
GET /api/v1/posts/slug/:slug
```

#### Create Post (Auth Required)
```http
POST /api/v1/posts
Authorization: Bearer <accessToken>
Content-Type: application/json

{
  "title": "My Blog Post",
  "content": "Full content here...",
  "excerpt": "Brief summary",
  "status": "published",
  "categories": ["categoryId1", "categoryId2"],
  "tags": ["javascript", "nodejs"],
  "metaTitle": "SEO Title",
  "metaDescription": "SEO Description",
  "allowComments": true,
  "isFeatured": false
}
```

#### Update Post (Owner/Admin)
```http
PATCH /api/v1/posts/:id
Authorization: Bearer <accessToken>
Content-Type: application/json

{
  "title": "Updated Title",
  "status": "published"
}
```

#### Delete Post (Owner/Admin)
```http
DELETE /api/v1/posts/:id
Authorization: Bearer <accessToken>
```

#### Like/Unlike Post (Auth Required)
```http
POST /api/v1/posts/:id/like
Authorization: Bearer <accessToken>
```

#### Upload Post Image (Auth Required)
```http
POST /api/v1/posts/:id/image
Authorization: Bearer <accessToken>
Content-Type: multipart/form-data

image: <file>
```

### Comment Endpoints

#### Get Post Comments
```http
GET /api/v1/posts/:postId/comments?page=1&limit=10
```

#### Create Comment (Auth Required)
```http
POST /api/v1/posts/:postId/comments
Authorization: Bearer <accessToken>
Content-Type: application/json

{
  "content": "Great post!",
  "parent": "parentCommentId" // Optional for replies
}
```

#### Update Comment (Owner/Admin)
```http
PATCH /api/v1/comments/:id
Authorization: Bearer <accessToken>
Content-Type: application/json

{
  "content": "Updated comment"
}
```

#### Delete Comment (Owner/Admin)
```http
DELETE /api/v1/comments/:id
Authorization: Bearer <accessToken>
```

#### Like Comment (Auth Required)
```http
POST /api/v1/comments/:id/like
Authorization: Bearer <accessToken>
```

### Category Endpoints

#### Get All Categories
```http
GET /api/v1/categories
```

#### Create Category (Admin)
```http
POST /api/v1/categories
Authorization: Bearer <accessToken>
Content-Type: application/json

{
  "name": "Technology",
  "description": "Tech related posts",
  "color": "#3B82F6",
  "parent": "parentCategoryId" // Optional
}
```

### User Endpoints

#### Get Profile (Auth Required)
```http
GET /api/v1/users/profile
Authorization: Bearer <accessToken>
```

#### Update Profile (Auth Required)
```http
PATCH /api/v1/users/profile
Authorization: Bearer <accessToken>
Content-Type: application/json

{
  "firstName": "John",
  "lastName": "Doe",
  "bio": "Software developer",
  "social": {
    "twitter": "https://twitter.com/johndoe",
    "github": "https://github.com/johndoe"
  }
}
```

#### Upload Profile Image (Auth Required)
```http
POST /api/v1/users/profile/image
Authorization: Bearer <accessToken>
Content-Type: multipart/form-data

image: <file>
```

#### Change Password (Auth Required)
```http
POST /api/v1/users/change-password
Authorization: Bearer <accessToken>
Content-Type: application/json

{
  "currentPassword": "OldPass123!",
  "newPassword": "NewPass123!",
  "confirmPassword": "NewPass123!"
}
```

### Admin Endpoints

#### Get Dashboard Stats (Admin)
```http
GET /api/v1/admin/stats
Authorization: Bearer <accessToken>
```

#### Get All Users (Admin)
```http
GET /api/v1/admin/users?page=1&limit=10&role=user&search=keyword
Authorization: Bearer <accessToken>
```

#### Ban User (Admin)
```http
POST /api/v1/admin/users/:id/ban
Authorization: Bearer <accessToken>
Content-Type: application/json

{
  "reason": "Spam activities"
}
```

#### Unban User (Admin)
```http
POST /api/v1/admin/users/:id/unban
Authorization: Bearer <accessToken>
```

#### Moderate Comment (Admin/Moderator)
```http
PATCH /api/v1/admin/comments/:id/moderate
Authorization: Bearer <accessToken>
Content-Type: application/json

{
  "status": "approved" // or "rejected", "spam"
}
```

## 🔐 Security Features

### Password Requirements
- Minimum 8 characters
- At least one uppercase letter
- At least one lowercase letter
- At least one number
- At least one special character (@$!%*?&)

### Rate Limiting
- General API: 100 requests per 15 minutes
- Authentication: 5 attempts per 15 minutes
- Password Reset: 3 attempts per hour
- Email Verification: 5 attempts per hour
- Post Creation: 10 posts per hour
- Comment Creation: 20 comments per 15 minutes
- File Upload: 10 uploads per 15 minutes

### Account Lockout
- Locked after 5 failed login attempts
- Lockout duration: 1 hour
- Automatic unlock after duration

### Token Management
- Access Token: 15 minutes expiry
- Refresh Token: 7 days expiry
- Refresh token rotation on use
- Tokens stored in HTTP-only cookies

## 📊 Database Schema

### User Collection
```javascript
{
  username: String (unique, indexed),
  email: String (unique, indexed, lowercase),
  password: String (hashed, select: false),
  firstName: String,
  lastName: String,
  bio: String,
  profileImage: { url, publicId },
  role: String (enum: user/author/moderator/admin),
  isEmailVerified: Boolean,
  isActive: Boolean,
  isBanned: Boolean,
  banReason: String,
  stats: { totalPosts, totalComments, totalLikes },
  social: { twitter, linkedin, github, website },
  timestamps: true
}
```

### Post Collection
```javascript
{
  title: String (indexed),
  slug: String (unique, indexed),
  content: String (text indexed),
  excerpt: String,
  featuredImage: { url, publicId, alt },
  author: ObjectId (ref: User, indexed),
  status: String (enum: draft/published/archived, indexed),
  categories: [ObjectId] (ref: Category),
  tags: [String] (indexed),
  metaTitle: String,
  metaDescription: String,
  metaKeywords: [String],
  likes: [ObjectId] (ref: User),
  likesCount: Number,
  commentsCount: Number,
  viewsCount: Number,
  readingTime: Number,
  publishedAt: Date,
  scheduledAt: Date,
  isFeatured: Boolean (indexed),
  isPinned: Boolean (indexed),
  allowComments: Boolean,
  isDeleted: Boolean (indexed),
  timestamps: true
}
```

### Comment Collection
```javascript
{
  content: String,
  author: ObjectId (ref: User, indexed),
  post: ObjectId (ref: Post, indexed),
  parent: ObjectId (ref: Comment, indexed),
  status: String (enum: pending/approved/rejected/spam, indexed),
  likes: [ObjectId] (ref: User),
  likesCount: Number,
  isEdited: Boolean,
  editedAt: Date,
  isDeleted: Boolean (indexed),
  reportCount: Number,
  reports: [{ user, reason, createdAt }],
  timestamps: true
}
```

### Category Collection
```javascript
{
  name: String (unique),
  slug: String (unique, indexed),
  description: String,
  color: String (hex),
  icon: String,
  parent: ObjectId (ref: Category),
  isActive: Boolean (indexed),
  postCount: Number,
  order: Number (indexed),
  timestamps: true
}
```

## 🧪 Testing

### Unit Tests
```bash
npm test
```

### Integration Tests
```bash
npm run test:integration
```

### Coverage Report
```bash
npm test -- --coverage
```

## 📈 Performance Optimizations

1. **Database Indexing**
   - All frequently queried fields are indexed
   - Compound indexes for complex queries
   - Text indexes for full-text search

2. **Redis Caching**
   - Refresh tokens
   - OTP codes
   - Failed login attempts
   - Rate limiting data

3. **Query Optimization**
   - Selective field projection
   - Pagination for large datasets
   - Efficient population of references

4. **Response Compression**
   - Gzip compression enabled
   - Reduces bandwidth usage

## 🚀 Deployment

### Docker Deployment (Recommended)
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["node", "src/server.js"]
```

### PM2 Deployment
```bash
npm install -g pm2
pm2 start src/server.js --name blog-api
pm2 save
pm2 startup
```

### Environment-Specific Configurations
- **Development**: Full logging, detailed errors
- **Production**: Minimal logging, generic errors, security headers

## 📝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 🐛 Troubleshooting

### Common Issues

**MongoDB Connection Failed**
- Check MongoDB is running
- Verify connection string
- Check network/firewall settings

**Redis Connection Error**
- Ensure Redis is running
- Verify Redis host and port
- Check Redis password if set

**Image Upload Failed**
- Verify Cloudinary credentials
- Check file size limits
- Ensure file type is allowed

**Email Not Sending**
- Verify SMTP credentials
- Check firewall/network
- Enable "Less secure apps" for Gmail or use app password

## 📄 License

MIT License - feel free to use this in your projects!

## 👨‍💻 Author

Your Name - Full Stack Developer

## 🙏 Acknowledgments

- Express.js team
- MongoDB team
- Redis team
- All open-source contributors

---

**Note**: This is a production-ready foundation. Always review and test thoroughly before deploying to production. Customize based on your specific needs.
