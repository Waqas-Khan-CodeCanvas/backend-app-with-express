import Redis from 'ioredis';
import { ENV } from './env.js';
import { logger } from './logger.js';

class RedisClient {
  constructor() {
    this.client = null;
    this.isConnected = false;
  }

  async connect() {
    try {
      if (this.isConnected) {
        logger.info('Redis is already connected');
        return this.client;
      }

      this.client = new Redis({
        host: ENV.REDIS_HOST,
        port: ENV.REDIS_PORT,
        password: ENV.REDIS_PASSWORD || undefined,
        db: ENV.REDIS_DB,
        retryStrategy: (times) => {
          const delay = Math.min(times * 50, 2000);
          return delay;
        },
        maxRetriesPerRequest: 3,
        enableReadyCheck: true,
        lazyConnect: true
      });

      // Event listeners
      this.client.on('connect', () => {
        logger.info('Redis client is connecting...');
      });

      this.client.on('ready', () => {
        this.isConnected = true;
        logger.info('✅ Redis connection established successfully');
      });

      this.client.on('error', (err) => {
        logger.error('Redis connection error:', err);
        this.isConnected = false;
      });

      this.client.on('close', () => {
        logger.warn('Redis connection closed');
        this.isConnected = false;
      });

      this.client.on('reconnecting', () => {
        logger.info('Redis client is reconnecting...');
      });

      await this.client.connect();
      return this.client;
    } catch (error) {
      logger.error('Failed to connect to Redis:', error);
      throw error;
    }
  }

  async disconnect() {
    if (this.client) {
      await this.client.quit();
      this.isConnected = false;
      logger.info('Redis disconnected successfully');
    }
  }

  getClient() {
    if (!this.isConnected || !this.client) {
      throw new Error('Redis client is not connected');
    }
    return this.client;
  }

  // Helper methods for common operations
  async get(key) {
    try {
      const value = await this.client.get(key);
      return value ? JSON.parse(value) : null;
    } catch (error) {
      logger.error(`Redis GET error for key ${key}:`, error);
      return null;
    }
  }

  async set(key, value, expiryInSeconds = null) {
    try {
      const stringValue = JSON.stringify(value);
      if (expiryInSeconds) {
        await this.client.setex(key, expiryInSeconds, stringValue);
      } else {
        await this.client.set(key, stringValue);
      }
      return true;
    } catch (error) {
      logger.error(`Redis SET error for key ${key}:`, error);
      return false;
    }
  }

  async del(key) {
    try {
      await this.client.del(key);
      return true;
    } catch (error) {
      logger.error(`Redis DEL error for key ${key}:`, error);
      return false;
    }
  }

  async exists(key) {
    try {
      const result = await this.client.exists(key);
      return result === 1;
    } catch (error) {
      logger.error(`Redis EXISTS error for key ${key}:`, error);
      return false;
    }
  }

  async incr(key) {
    try {
      return await this.client.incr(key);
    } catch (error) {
      logger.error(`Redis INCR error for key ${key}:`, error);
      return null;
    }
  }

  async expire(key, seconds) {
    try {
      await this.client.expire(key, seconds);
      return true;
    } catch (error) {
      logger.error(`Redis EXPIRE error for key ${key}:`, error);
      return false;
    }
  }

  async ttl(key) {
    try {
      return await this.client.ttl(key);
    } catch (error) {
      logger.error(`Redis TTL error for key ${key}:`, error);
      return -1;
    }
  }

  async flushAll() {
    try {
      await this.client.flushall();
      logger.info('Redis cache cleared');
      return true;
    } catch (error) {
      logger.error('Redis FLUSHALL error:', error);
      return false;
    }
  }

  // Refresh token rotation
  async storeRefreshToken(userId, token, expiryInSeconds) {
    const key = `refresh_token:${userId}`;
    return await this.set(key, token, expiryInSeconds);
  }

  async getRefreshToken(userId) {
    const key = `refresh_token:${userId}`;
    return await this.get(key);
  }

  async deleteRefreshToken(userId) {
    const key = `refresh_token:${userId}`;
    return await this.del(key);
  }

  // OTP management
  async storeOTP(email, otp, expiryInSeconds) {
    const key = `otp:${email}`;
    return await this.set(key, otp, expiryInSeconds);
  }

  async getOTP(email) {
    const key = `otp:${email}`;
    return await this.get(key);
  }

  async deleteOTP(email) {
    const key = `otp:${email}`;
    return await this.del(key);
  }

  // Failed login tracking
  async incrementFailedLogin(email) {
    const key = `failed_login:${email}`;
    const count = await this.incr(key);
    await this.expire(key, ENV.LOCK_TIME / 1000); // Set expiry to lock time
    return count;
  }

  async getFailedLoginCount(email) {
    const key = `failed_login:${email}`;
    const count = await this.get(key);
    return count || 0;
  }

  async resetFailedLogin(email) {
    const key = `failed_login:${email}`;
    return await this.del(key);
  }

  // Account lock
  async lockAccount(email) {
    const key = `account_lock:${email}`;
    return await this.set(key, true, ENV.LOCK_TIME / 1000);
  }

  async isAccountLocked(email) {
    const key = `account_lock:${email}`;
    return await this.exists(key);
  }

  async unlockAccount(email) {
    const key = `account_lock:${email}`;
    return await this.del(key);
  }
}

// Create singleton instance
const redisClient = new RedisClient();

export { redisClient };
