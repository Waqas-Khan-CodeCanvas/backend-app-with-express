import "dotenv/config";

const requiredEnvVariables = [
  "PORT",
  "NODE_ENV",
  "MONGODB_URI",
  "CORS_ORIGIN",
  "JWT_ACCESS_TOKEN_SECRET_KEY",
  "JWT_ACCESS_TOKEN_EXPIRY",
  "JWT_REFRESH_TOKEN_SECRET_KEY",
  "JWT_REFRESH_TOKEN_EXPIRY",
  "REDIS_HOST",
  "REDIS_PORT"
];

// Validate required environment variables
requiredEnvVariables.forEach((key) => {
  if (!process.env[key]) {
    console.error(`❌ Missing required environment variable: ${key}`);
    process.exit(1);
  }
});

export const ENV = {
  // Server
  PORT: Number(process.env.PORT) || 5000,
  NODE_ENV: process.env.NODE_ENV || 'development',
  
  // Database
  MONGODB_URI: process.env.MONGODB_URI,
  MONGODB_TEST_URI: process.env.MONGODB_TEST_URI,
  
  // Redis
  REDIS_HOST: process.env.REDIS_HOST || 'localhost',
  REDIS_PORT: Number(process.env.REDIS_PORT) || 6379,
  REDIS_PASSWORD: process.env.REDIS_PASSWORD || '',
  REDIS_DB: Number(process.env.REDIS_DB) || 0,
  
  // CORS
  CORS_ORIGIN: process.env.CORS_ORIGIN,
  
  // JWT
  JWT_ACCESS_TOKEN_SECRET_KEY: process.env.JWT_ACCESS_TOKEN_SECRET_KEY,
  JWT_ACCESS_TOKEN_EXPIRY: process.env.JWT_ACCESS_TOKEN_EXPIRY || '15m',
  JWT_REFRESH_TOKEN_SECRET_KEY: process.env.JWT_REFRESH_TOKEN_SECRET_KEY,
  JWT_REFRESH_TOKEN_EXPIRY: process.env.JWT_REFRESH_TOKEN_EXPIRY || '7d',
  JWT_EMAIL_VERIFICATION_SECRET: process.env.JWT_EMAIL_VERIFICATION_SECRET || process.env.JWT_ACCESS_TOKEN_SECRET_KEY,
  JWT_PASSWORD_RESET_SECRET: process.env.JWT_PASSWORD_RESET_SECRET || process.env.JWT_ACCESS_TOKEN_SECRET_KEY,
  
  // Cloudinary
  CLOUDINARY_CLOUD_NAME: process.env.CLOUDINARY_CLOUD_NAME,
  CLOUDINARY_API_KEY: process.env.CLOUDINARY_API_KEY,
  CLOUDINARY_API_SECRET: process.env.CLOUDINARY_API_SECRET,
  
  // Email
  SMTP_HOST: process.env.SMTP_HOST || 'smtp.gmail.com',
  SMTP_PORT: Number(process.env.SMTP_PORT) || 587,
  SMTP_SECURE: process.env.SMTP_SECURE === 'true',
  SMTP_USER: process.env.SMTP_USER,
  SMTP_PASSWORD: process.env.SMTP_PASSWORD,
  EMAIL_FROM: process.env.EMAIL_FROM || 'noreply@blog.com',
  
  // Frontend URLs
  FRONTEND_URL: process.env.FRONTEND_URL || 'http://localhost:3000',
  ADMIN_PANEL_URL: process.env.ADMIN_PANEL_URL || 'http://localhost:3001',
  
  // Rate Limiting
  RATE_LIMIT_WINDOW_MS: Number(process.env.RATE_LIMIT_WINDOW_MS) || 900000, // 15 minutes
  RATE_LIMIT_MAX_REQUESTS: Number(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
  
  // Security
  BCRYPT_SALT_ROUNDS: Number(process.env.BCRYPT_SALT_ROUNDS) || 12,
  MAX_LOGIN_ATTEMPTS: Number(process.env.MAX_LOGIN_ATTEMPTS) || 5,
  LOCK_TIME: Number(process.env.LOCK_TIME) || 3600000, // 1 hour
  
  // Pagination
  DEFAULT_PAGE_SIZE: Number(process.env.DEFAULT_PAGE_SIZE) || 10,
  MAX_PAGE_SIZE: Number(process.env.MAX_PAGE_SIZE) || 100,
  
  // File Upload
  MAX_FILE_SIZE: Number(process.env.MAX_FILE_SIZE) || 5242880, // 5MB
  ALLOWED_FILE_TYPES: process.env.ALLOWED_FILE_TYPES?.split(',') || ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  
  // Session
  SESSION_SECRET: process.env.SESSION_SECRET,
  
  // OTP
  OTP_EXPIRY: Number(process.env.OTP_EXPIRY) || 600000, // 10 minutes
  OTP_LENGTH: Number(process.env.OTP_LENGTH) || 6,
  
  // Admin
  ADMIN_EMAIL: process.env.ADMIN_EMAIL,
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD
};

// Validate production-specific requirements
if (ENV.NODE_ENV === 'production') {
  const productionRequired = [
    'CLOUDINARY_CLOUD_NAME',
    'CLOUDINARY_API_KEY', 
    'CLOUDINARY_API_SECRET',
    'SMTP_USER',
    'SMTP_PASSWORD'
  ];
  
  const missing = productionRequired.filter(key => !process.env[key]);
  
  if (missing.length > 0) {
    console.warn(`⚠️  Production warning: Missing optional variables: ${missing.join(', ')}`);
  }
}
