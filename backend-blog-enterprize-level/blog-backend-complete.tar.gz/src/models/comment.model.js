import mongoose from 'mongoose';
import { COMMENT_STATUS } from '../constants/index.js';

const commentSchema = new mongoose.Schema(
  {
    content: {
      type: String,
      required: [true, 'Comment content is required'],
      trim: true,
      minlength: [2, 'Comment must be at least 2 characters'],
      maxlength: [1000, 'Comment cannot exceed 1000 characters']
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true
    },
    post: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Post',
      required: true,
      index: true
    },
    parent: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Comment',
      default: null,
      index: true
    },
    status: {
      type: String,
      enum: Object.values(COMMENT_STATUS),
      default: COMMENT_STATUS.APPROVED, // Auto-approve by default, can be changed to PENDING
      index: true
    },
    likes: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }],
    likesCount: {
      type: Number,
      default: 0
    },
    isEdited: {
      type: Boolean,
      default: false
    },
    editedAt: Date,
    isDeleted: {
      type: Boolean,
      default: false,
      index: true
    },
    deletedAt: Date,
    // Moderation
    reportCount: {
      type: Number,
      default: 0
    },
    reports: [{
      user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
      },
      reason: String,
      createdAt: {
        type: Date,
        default: Date.now
      }
    }]
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Indexes
commentSchema.index({ post: 1, status: 1, createdAt: -1 });
commentSchema.index({ author: 1, createdAt: -1 });
commentSchema.index({ parent: 1 });
commentSchema.index({ isDeleted: 1, status: 1 });

// Virtual for replies
commentSchema.virtual('replies', {
  ref: 'Comment',
  localField: '_id',
  foreignField: 'parent',
  options: { sort: { createdAt: 1 } }
});

// Pre-save middleware
commentSchema.pre('save', function(next) {
  if (this.isModified('content') && !this.isNew) {
    this.isEdited = true;
    this.editedAt = new Date();
  }
  next();
});

// Post-save middleware to update post comment count
commentSchema.post('save', async function() {
  if (!this.isDeleted && this.status === COMMENT_STATUS.APPROVED) {
    await mongoose.model('Post').findByIdAndUpdate(
      this.post,
      { $inc: { commentsCount: 1 } }
    );
  }
});

// Post-remove middleware to update post comment count
commentSchema.post('findOneAndDelete', async function(doc) {
  if (doc && doc.status === COMMENT_STATUS.APPROVED) {
    await mongoose.model('Post').findByIdAndUpdate(
      doc.post,
      { $inc: { commentsCount: -1 } }
    );
  }
});

// Method to check if user has liked the comment
commentSchema.methods.isLikedBy = function(userId) {
  return this.likes.some(like => like.toString() === userId.toString());
};

// Method to toggle like
commentSchema.methods.toggleLike = async function(userId) {
  const isLiked = this.isLikedBy(userId);
  
  if (isLiked) {
    this.likes = this.likes.filter(like => like.toString() !== userId.toString());
    this.likesCount = Math.max(0, this.likesCount - 1);
  } else {
    this.likes.push(userId);
    this.likesCount += 1;
  }
  
  await this.save();
  return !isLiked;
};

// Method to soft delete
commentSchema.methods.softDelete = async function() {
  this.isDeleted = true;
  this.deletedAt = new Date();
  await this.save();
  
  // Update post comment count
  await mongoose.model('Post').findByIdAndUpdate(
    this.post,
    { $inc: { commentsCount: -1 } }
  );
};

// Method to restore
commentSchema.methods.restore = async function() {
  this.isDeleted = false;
  this.deletedAt = null;
  await this.save();
  
  // Update post comment count
  if (this.status === COMMENT_STATUS.APPROVED) {
    await mongoose.model('Post').findByIdAndUpdate(
      this.post,
      { $inc: { commentsCount: 1 } }
    );
  }
};

// Method to approve comment
commentSchema.methods.approve = async function() {
  if (this.status !== COMMENT_STATUS.APPROVED) {
    const wasNotApproved = true;
    this.status = COMMENT_STATUS.APPROVED;
    await this.save();
    
    // Increment post comment count
    if (wasNotApproved) {
      await mongoose.model('Post').findByIdAndUpdate(
        this.post,
        { $inc: { commentsCount: 1 } }
      );
    }
  }
};

// Method to reject comment
commentSchema.methods.reject = async function() {
  if (this.status === COMMENT_STATUS.APPROVED) {
    await mongoose.model('Post').findByIdAndUpdate(
      this.post,
      { $inc: { commentsCount: -1 } }
    );
  }
  this.status = COMMENT_STATUS.REJECTED;
  await this.save();
};

// Method to mark as spam
commentSchema.methods.markAsSpam = async function() {
  if (this.status === COMMENT_STATUS.APPROVED) {
    await mongoose.model('Post').findByIdAndUpdate(
      this.post,
      { $inc: { commentsCount: -1 } }
    );
  }
  this.status = COMMENT_STATUS.SPAM;
  await this.save();
};

export const Comment = mongoose.model('Comment', commentSchema);
