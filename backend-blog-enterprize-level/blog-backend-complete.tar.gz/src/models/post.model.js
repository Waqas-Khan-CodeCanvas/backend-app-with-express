import mongoose from 'mongoose';
import slug from 'slug';
import { POST_STATUS } from '../constants/index.js';

const postSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true,
      minlength: [5, 'Title must be at least 5 characters'],
      maxlength: [200, 'Title cannot exceed 200 characters']
    },
    slug: {
      type: String,
      unique: true,
      lowercase: true,
      index: true
    },
    content: {
      type: String,
      required: [true, 'Content is required'],
      minlength: [50, 'Content must be at least 50 characters']
    },
    excerpt: {
      type: String,
      maxlength: [300, 'Excerpt cannot exceed 300 characters']
    },
    featuredImage: {
      url: { type: String, default: '' },
      publicId: { type: String, default: '' },
      alt: { type: String, default: '' }
    },
    author: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true
    },
    status: {
      type: String,
      enum: Object.values(POST_STATUS),
      default: POST_STATUS.DRAFT,
      index: true
    },
    categories: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Category'
    }],
    tags: [{
      type: String,
      trim: true,
      lowercase: true
    }],
    // SEO fields
    metaTitle: {
      type: String,
      maxlength: [60, 'Meta title cannot exceed 60 characters']
    },
    metaDescription: {
      type: String,
      maxlength: [160, 'Meta description cannot exceed 160 characters']
    },
    metaKeywords: [{
      type: String,
      trim: true
    }],
    // Engagement
    likes: [{
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    }],
    likesCount: {
      type: Number,
      default: 0
    },
    commentsCount: {
      type: Number,
      default: 0
    },
    viewsCount: {
      type: Number,
      default: 0
    },
    // Publishing
    publishedAt: Date,
    scheduledAt: Date,
    // Soft delete
    isDeleted: {
      type: Boolean,
      default: false,
      index: true
    },
    deletedAt: Date,
    // Reading time in minutes
    readingTime: {
      type: Number,
      default: 0
    },
    // Featured/pinned posts
    isFeatured: {
      type: Boolean,
      default: false
    },
    isPinned: {
      type: Boolean,
      default: false
    },
    // Comments enabled/disabled
    allowComments: {
      type: Boolean,
      default: true
    }
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
  }
);

// Indexes for better performance
postSchema.index({ slug: 1 });
postSchema.index({ author: 1, status: 1 });
postSchema.index({ status: 1, publishedAt: -1 });
postSchema.index({ createdAt: -1 });
postSchema.index({ tags: 1 });
postSchema.index({ categories: 1 });
postSchema.index({ isDeleted: 1, status: 1 });
postSchema.index({ isFeatured: 1, isPinned: 1 });

// Text index for search
postSchema.index({ 
  title: 'text', 
  content: 'text', 
  excerpt: 'text',
  tags: 'text'
});

// Virtual for comments
postSchema.virtual('comments', {
  ref: 'Comment',
  localField: '_id',
  foreignField: 'post',
  options: { sort: { createdAt: -1 } }
});

// Pre-save middleware to generate slug
postSchema.pre('save', async function(next) {
  if (this.isModified('title') || !this.slug) {
    let baseSlug = slug(this.title, { lower: true });
    let uniqueSlug = baseSlug;
    let counter = 1;

    // Ensure slug is unique
    while (await mongoose.models.Post.findOne({ slug: uniqueSlug, _id: { $ne: this._id } })) {
      uniqueSlug = `${baseSlug}-${counter}`;
      counter++;
    }

    this.slug = uniqueSlug;
  }

  // Calculate reading time (average 200 words per minute)
  if (this.isModified('content')) {
    const wordsPerMinute = 200;
    const wordCount = this.content.split(/\s+/).length;
    this.readingTime = Math.ceil(wordCount / wordsPerMinute);
  }

  // Auto-generate excerpt if not provided
  if (!this.excerpt && this.content) {
    this.excerpt = this.content.substring(0, 200).trim() + '...';
  }

  // Set published date when status changes to published
  if (this.isModified('status') && this.status === POST_STATUS.PUBLISHED && !this.publishedAt) {
    this.publishedAt = new Date();
  }

  next();
});

// Method to check if user has liked the post
postSchema.methods.isLikedBy = function(userId) {
  return this.likes.some(like => like.toString() === userId.toString());
};

// Method to toggle like
postSchema.methods.toggleLike = async function(userId) {
  const isLiked = this.isLikedBy(userId);
  
  if (isLiked) {
    this.likes = this.likes.filter(like => like.toString() !== userId.toString());
    this.likesCount = Math.max(0, this.likesCount - 1);
  } else {
    this.likes.push(userId);
    this.likesCount += 1;
  }
  
  await this.save();
  return !isLiked; // Return new like status
};

// Static method to get published posts
postSchema.statics.getPublished = function(query = {}) {
  return this.find({
    ...query,
    status: POST_STATUS.PUBLISHED,
    isDeleted: false
  });
};

// Static method to soft delete
postSchema.methods.softDelete = async function() {
  this.isDeleted = true;
  this.deletedAt = new Date();
  await this.save();
};

// Static method to restore soft deleted post
postSchema.methods.restore = async function() {
  this.isDeleted = false;
  this.deletedAt = null;
  await this.save();
};

export const Post = mongoose.model('Post', postSchema);
