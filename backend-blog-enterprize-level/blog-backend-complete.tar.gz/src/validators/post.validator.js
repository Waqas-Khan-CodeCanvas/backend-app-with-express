import Joi from 'joi';
import { POST_STATUS } from '../constants/index.js';

const objectIdSchema = Joi.string().regex(/^[0-9a-fA-F]{24}$/).messages({
  'string.pattern.base': 'Invalid ID format'
});

export const createPostSchema = Joi.object({
  title: Joi.string()
    .min(5)
    .max(200)
    .required()
    .messages({
      'string.min': 'Title must be at least 5 characters',
      'string.max': 'Title cannot exceed 200 characters',
      'any.required': 'Title is required'
    }),
  content: Joi.string()
    .min(50)
    .required()
    .messages({
      'string.min': 'Content must be at least 50 characters',
      'any.required': 'Content is required'
    }),
  excerpt: Joi.string()
    .max(300)
    .optional()
    .allow(''),
  status: Joi.string()
    .valid(...Object.values(POST_STATUS))
    .default(POST_STATUS.DRAFT),
  categories: Joi.array()
    .items(objectIdSchema)
    .optional(),
  tags: Joi.array()
    .items(Joi.string().trim().lowercase())
    .optional(),
  metaTitle: Joi.string()
    .max(60)
    .optional()
    .allow(''),
  metaDescription: Joi.string()
    .max(160)
    .optional()
    .allow(''),
  metaKeywords: Joi.array()
    .items(Joi.string().trim())
    .optional(),
  allowComments: Joi.boolean()
    .optional(),
  isFeatured: Joi.boolean()
    .optional(),
  isPinned: Joi.boolean()
    .optional(),
  scheduledAt: Joi.date()
    .greater('now')
    .optional()
});

export const updatePostSchema = Joi.object({
  title: Joi.string()
    .min(5)
    .max(200)
    .optional(),
  content: Joi.string()
    .min(50)
    .optional(),
  excerpt: Joi.string()
    .max(300)
    .optional()
    .allow(''),
  status: Joi.string()
    .valid(...Object.values(POST_STATUS))
    .optional(),
  categories: Joi.array()
    .items(objectIdSchema)
    .optional(),
  tags: Joi.array()
    .items(Joi.string().trim().lowercase())
    .optional(),
  metaTitle: Joi.string()
    .max(60)
    .optional()
    .allow(''),
  metaDescription: Joi.string()
    .max(160)
    .optional()
    .allow(''),
  metaKeywords: Joi.array()
    .items(Joi.string().trim())
    .optional(),
  allowComments: Joi.boolean()
    .optional(),
  isFeatured: Joi.boolean()
    .optional(),
  isPinned: Joi.boolean()
    .optional(),
  scheduledAt: Joi.date()
    .greater('now')
    .optional()
    .allow(null)
});

export const getPostsQuerySchema = Joi.object({
  page: Joi.number()
    .integer()
    .min(1)
    .default(1),
  limit: Joi.number()
    .integer()
    .min(1)
    .max(100)
    .default(10),
  sort: Joi.string()
    .valid('createdAt', '-createdAt', 'updatedAt', '-updatedAt', 'title', '-title', 'likesCount', '-likesCount', 'viewsCount', '-viewsCount')
    .default('-createdAt'),
  status: Joi.string()
    .valid(...Object.values(POST_STATUS))
    .optional(),
  author: objectIdSchema.optional(),
  category: objectIdSchema.optional(),
  tag: Joi.string().optional(),
  search: Joi.string().optional(),
  isFeatured: Joi.boolean().optional(),
  isPinned: Joi.boolean().optional()
});

export const postIdParamSchema = Joi.object({
  id: objectIdSchema.required()
});

export const slugParamSchema = Joi.object({
  slug: Joi.string()
    .required()
    .messages({
      'any.required': 'Slug is required'
    })
});
