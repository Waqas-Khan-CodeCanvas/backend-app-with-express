import { ApiError } from '../utils/apiError.js';
import { HTTP_STATUS, ERROR_MESSAGES, USER_ROLES } from '../constants/index.js';

/**
 * Check if user has required role(s)
 * @param {...string} roles - Allowed roles
 * @returns {Function} Express middleware
 */
export const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return next(
        new ApiError(
          HTTP_STATUS.UNAUTHORIZED,
          ERROR_MESSAGES.UNAUTHORIZED
        )
      );
    }

    if (!roles.includes(req.user.role)) {
      return next(
        new ApiError(
          HTTP_STATUS.FORBIDDEN,
          'You do not have permission to perform this action'
        )
      );
    }

    next();
  };
};

/**
 * Check if user is admin
 */
export const isAdmin = authorize(USER_ROLES.ADMIN);

/**
 * Check if user is admin or moderator
 */
export const isModerator = authorize(USER_ROLES.ADMIN, USER_ROLES.MODERATOR);

/**
 * Check if user is author, admin, or moderator
 */
export const isAuthor = authorize(USER_ROLES.ADMIN, USER_ROLES.MODERATOR, USER_ROLES.AUTHOR);

/**
 * Check if user is the owner of the resource or admin
 */
export const isOwnerOrAdmin = (resourceUserIdField = 'author') => {
  return (req, res, next) => {
    if (!req.user) {
      return next(
        new ApiError(
          HTTP_STATUS.UNAUTHORIZED,
          ERROR_MESSAGES.UNAUTHORIZED
        )
      );
    }

    // Admin can access everything
    if (req.user.role === USER_ROLES.ADMIN) {
      return next();
    }

    // Check if user owns the resource
    const resourceUserId = req.resource?.[resourceUserIdField]?.toString() || 
                          req.params?.userId?.toString();
    const currentUserId = req.user._id.toString();

    if (resourceUserId !== currentUserId) {
      return next(
        new ApiError(
          HTTP_STATUS.FORBIDDEN,
          'You can only modify your own resources'
        )
      );
    }

    next();
  };
};
